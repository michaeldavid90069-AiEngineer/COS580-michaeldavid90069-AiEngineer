Week 4 Discussion: Peer Response & Support Vector Machine Implementation
Author: Michael David
Dataset: flight_prices.csv (Regression Track)
Target Classmate: Onyekachi Onyenokwe

1. Project Overview
This repository addition fulfills the Week 4 peer response requirements by appending a Support Vector Regressor (SVR) model to a classmate's existing Jupyter Notebook. The objective is to evaluate whether the SVR can outperform the classmate's baseline Decision Tree and Random Forest models using their exact training and testing splits.

2. Environment & Dependency Updates
Dependency Resolution: Added a specific pip installation command (!pip install RegscorePy) at the top of the notebook to resolve a ModuleNotFoundError triggered by the original author's AIC calculation dependency.

Data Scaling: Implemented sklearn.preprocessing.StandardScaler prior to SVR training. Support Vector Machines utilize physical distance calculations between data points; feeding unscaled features drastically reduces model accuracy and inflates processing time.

3. Model Architecture & Hyperparameters
The flight_prices dataset was partitioned using the original 75/25 train-test split (random_state=42). The SVR was configured with the following hyperparameters to prevent overfitting while mapping complex price relationships:

Algorithm: Support Vector Regressor (SVR)

Kernel: Radial Basis Function (kernel='rbf') to capture non-linear relationships in flight parameters.

Regularization (C): C=1.0 to establish a balanced penalty for data points falling outside the acceptable margin.

Epsilon Margin: epsilon=0.1 to explicitly define the width of the no-penalty zone (the "epsilon tube").

4. Evaluation Metrics
Strictly adhering to the regression track constraints, the SVR was evaluated using only R-squared, Akaike Information Criterion (AIC), and Mean Squared Error (MSE). The output was formatted using a zebra-striped Pandas DataFrame for enhanced visual presentation.

Final Comparative Results:

Random Forest (Original): R-squared: 0.960 | AIC: -24074.528 | MSE: 0.039

Support Vector Regressor (New): R-squared: 0.949 | AIC: -22214.012 | MSE: 0.051

Decision Tree (Original): R-squared: 0.940 | AIC: -21100.809 | MSE: 0.059

Conclusion: The Random Forest remains the optimal model for this dataset due to its ensemble averaging capabilities, though the SVR successfully outperformed the standalone Decision Tree.

5. Peer Response Documentation
A four-paragraph discussion post was drafted adhering strictly to the RISE Model (Reflect, Inquire, Suggest, Elevate). The text was explicitly engineered to reflect a natural, conversational student voice while maintaining robust technical accuracy regarding regularization, epsilon margins, and scaling prerequisites.